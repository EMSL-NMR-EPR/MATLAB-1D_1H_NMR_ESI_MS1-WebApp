/*
    For information on license, see: ${PROJECT_DIRECTORY}/LICENSE
 */

package rmi.tasks;

import com.mathworks.toolbox.javabuilder.MWException;
import java.io.*;
import java.util.List;
import java.util.logging.*;
import java.util.stream.Stream;
import match_to_Chenomx.Class1;
import remote_proxy.Task;


public class NMRMSTranslatorTask extends Class1 implements Task<Object[]>, Serializable {

    private final String db;
    private final List<String> files;
    private final File parent;

    public NMRMSTranslatorTask(String db, List<String> files, File parent) throws MWException {
        this.db = db;
        this.files = files;
        this.parent = parent;
    }

    
    @Override
    public Object[] doTask() {
        try {
            return doTaskHelper(db,files);
        } catch (MWException ex) {
            Logger.getLogger(NMRMSTranslatorTask.class.getName()).log(Level.SEVERE, null, ex);
            Stream.of(parent.listFiles()).forEach(File::delete);
            parent.delete();
            return null;
        }
    }
    
    private Object[] doTaskHelper(String db, List<String> files) throws MWException {
        if (files.size() == 2)
            return this.match_to_Chenomx(1, db, files.get(0), files.get(1));
        else
            return this.match_to_Chenomx(1, db, files.get(0), files.get(1), files.get(2));
    }
}
