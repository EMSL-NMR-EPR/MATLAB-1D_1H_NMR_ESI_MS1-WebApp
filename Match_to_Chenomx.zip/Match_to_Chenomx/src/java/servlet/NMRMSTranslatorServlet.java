/*
    For information on license, see: ${PROJECT_DIRECTORY}/LICENSE
 */
package servlet;

import com.fasterxml.jackson.core.*;
import com.mathworks.toolbox.javabuilder.*;
import java.io.*;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.nio.channels.WritableByteChannel;
import java.nio.charset.Charset;
import java.nio.file.*;
import static java.nio.file.StandardOpenOption.*;
import java.nio.file.attribute.FileTime;
import java.rmi.*;
import java.util.*;
import java.util.logging.*;
import java.util.stream.*;
import java.util.zip.*;
import javax.annotation.Resource;
import javax.enterprise.concurrent.ManagedExecutorService;
import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;
import remote_proxy.Task;
import rmi.tasks.*;
import util.IOUtils;
import static java.util.stream.Collectors.joining;

@WebServlet(urlPatterns = {"/NMRMSTranslator", "/NMRMSTranslator/graphs", "/NMRMSTranslator/download",
    "/NMRMSTranslator/compounds", "/NMRMSTranslator/download-all"})
@MultipartConfig
public class NMRMSTranslatorServlet extends HttpServlet {

    @Resource(name = "java:comp/DefaultManagedExecutorService")
    private ManagedExecutorService pool;

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        ServletContext sc = getServletContext();
        Path userDir = ((Path) request.getSession().getAttribute("userDir"));
        switch (request.getServletPath()) {
            case "/NMRMSTranslator":
                response.setContentType("text/html");
                try (Writer writer = response.getWriter();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(sc.getResourceAsStream(request.getParameter("resourceName"))))) {
                    reader.lines().forEach(e -> {
                        try {
                            writer.write(e);
                        } catch (IOException ex) {
                            Logger.getLogger(NMRMSTranslatorServlet.class.getName()).log(Level.SEVERE, null, ex);
                        }
                    });
                }
                break;
                
            case "/NMRMSTranslator/download":
                String excelFileName = request.getParameter("url");
                Path csv = userDir.resolve("csv").resolve(excelFileName);
                response.setHeader("Content-Disposition", "attachment;filename=" + excelFileName);
                response.setContentType("application/octet-stream");
                try (ReadableByteChannel rChannel = Files.newByteChannel(csv, READ);
                    WritableByteChannel wChannel = Channels.newChannel(new BufferedOutputStream(response.getOutputStream()))) {
                    IOUtils.write(rChannel, wChannel);
                }
                break;
                
            case "/NMRMSTranslator/download-all":
                csv = userDir.resolve("csv");
                try (ZipOutputStream zipOs = new ZipOutputStream(new BufferedOutputStream(Files.newOutputStream(csv.resolveSibling("csv.zip"))))) {
                    Arrays.stream(csv.toFile().listFiles()).forEach(file -> zip(zipOs, file));
                }               
                response.setHeader("Content-Disposition", "attachment;filename=csv.zip");
                response.setContentType("application/octet-stream");
                try (ReadableByteChannel rChannel = Files.newByteChannel(csv.resolveSibling("csv.zip"));
                    WritableByteChannel wChannel = Channels.newChannel(new BufferedOutputStream(response.getOutputStream()))) {
                    IOUtils.write(rChannel, wChannel);
                }
                break;
                
            case "/NMRMSTranslator/compounds":
                response.setContentType("application/json");
                Path names = userDir.getParent().resolveSibling("compound_names.txt");
                BufferedReader bf = Files.newBufferedReader(names, Charset.forName("ISO-8859-1"));
                try (Writer writer = response.getWriter();
                    JsonGenerator generator = ((JsonFactory) sc.getAttribute("JSON_FACTORY")).createJsonGenerator(writer)) {
                    generator.writeStartObject();
                    generator.writeArrayFieldStart("compounds");
                    bf.lines().forEach(str -> writeJsonString(generator, str));
                    generator.writeEndArray();
                    generator.writeEndObject();
                }
                break;
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        ServletContext sc = getServletContext();
        Path userDir = ((Path) request.getSession().getAttribute("userDir"));
        try {
            switch (request.getServletPath()) {
                case "/NMRMSTranslator/graphs":
                    graphs((JsonFactory) sc.getAttribute("JSON_FACTORY"), userDir, String.valueOf(new Date().getTime()), request, response);
                    break;
            }
        } catch (IOException ex) {
            Logger.getLogger(NMRMSTranslatorServlet.class.getName()).log(Level.SEVERE, null, ex);
            response.sendError(500);
        }
    }

    private void zip(ZipOutputStream os, File file) {
        try (ReadableByteChannel rChannel = Files.newByteChannel(file.toPath(), READ)) {
            os.putNextEntry(new ZipEntry(file.getName()));
            WritableByteChannel wChannel = Channels.newChannel(os);
            IOUtils.write(rChannel, wChannel);
            os.closeEntry();
        } catch (IOException ex) {
            Logger.getLogger(NMRMSTranslatorServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void graphs(JsonFactory factory, Path userDir, String randStr, HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json");
        Path transientDir = userDir.resolve(randStr);
        Files.createDirectory(transientDir);
        Writer writer = response.getWriter();
        try (JsonGenerator generator = factory.createJsonGenerator(writer)) {
            Part file1 = request.getPart("file1");
            if (file1.getSubmittedFileName() != null)
                IOUtils.copy(file1, transientDir);
            else
                try (BufferedWriter bw = Files.newBufferedWriter(transientDir.resolve("file1_list.txt"))) {
                    bw.write(request.getParameter(file1.getName()));
                }
            /*
            Not needed for now
            String username = request.getParameter("username");
            String institution = request.getParameter("institution");*/
            
            IOUtils.copy(request.getPart("file2"), transientDir);
            Part file3 = request.getPart("file3");
            if (file3 != null)
                IOUtils.copy(file3, transientDir);
            List<String> fileNames = Files.list(transientDir)
                    .filter(f -> !f.toFile().isHidden())
                    .map(f -> f.toString())
                    .collect(() -> new ArrayList(3), ArrayList::add, ArrayList::addAll);
            Task<Object[]> task = new NMRMSTranslatorTask(userDir.getParent().resolveSibling("MS_database.mat").toString(), fileNames, transientDir.toFile());
            MWStructArray struct = cast(Tasks.runTask(pool, task, userDir.getParent().getParent().toString(), "match_to_Chenomx_v4.jar")[0]);
            Map<String, double[]> pairs = new HashMap<>();
            Map<String, Object[][]> nameLists = new HashMap<>(2);
            generator.writeStartObject();
            for (String field : struct.fieldNames()) {
                generator.writeArrayFieldStart(field);
                if (field.equalsIgnoreCase("pos_name_list") || field.equalsIgnoreCase("neg_name_list")) {
                    Object[][] nameList = (Object[][])((MWCellArray)struct.getField(field,1)).toArray();
                    nameLists.put(field, nameList);
                    for (Object[] obj: nameList) {
                        generator.writeStartArray();
                        for (Object chars: obj) {
                            char[][] name = (char[][])chars;
                            generator.writeString(name.length == 0 ? "" : new String(name[0]));
                        }
                        generator.writeEndArray();
                    }
                }
                else {
                    double[] values = ((MWNumericArray) struct.getField(field, 1)).getDoubleData();
                    pairs.put(field, values);
                    for (double data : values)
                        generator.writeNumber(data);
                }
                
                generator.writeEndArray();
            }
            Path excel = saveDataInCsv(userDir.resolve("csv"), pairs, nameLists);
            generator.writeStringField("url", excel.getName(excel.getNameCount() - 1).toString());

            FileTime attr = (FileTime) Files.getAttribute(excel, "basic:creationTime");
            generator.writeNumberField("creationTime", attr.toMillis());
            generator.writeEndObject();
        } catch (ServletException | MWException | RemoteException | NotBoundException ex) {
            Logger.getLogger(NMRMSTranslatorServlet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private Path saveDataInCsv(Path csv, Map<String, double[]> data, Map<String, Object[][]> nameLists) throws IOException {
        String[] headers = {"mass_list_pos1", "mass_list_pos2", "list_pos1", "list_pos2", "pos_name_list",
            "mass_list_neg1", "mass_list_neg2", "list_neg1", "list_neg2", "neg_name_list"};
        int limit = data.values()
                .stream()
                .mapToInt(array -> array.length)
                .max()
                .getAsInt();
        Path excel = Files.createFile(csv.resolve("result_" + new Random().nextInt(13549) + ".csv"));
        String[] list = new String[headers.length];
        try (BufferedWriter writer = Files.newBufferedWriter(excel)) {
            writer.write(Stream.of(headers).collect(joining(",")));
            for (int i = 0; i < limit; i++) {
                for (int j = 0; j < headers.length; j++) {
                    try {
                        if (j == 4 || j == 9)
                            list[j] = writeCompoundNames(nameLists.get(headers[j])[i]);
                        else
                            list[j] = String.valueOf(data.get(headers[j])[i]);
                    } catch (Exception ex) {
                        list[j] = "";
                    }
                }
                writer.newLine();
                writer.write(Stream.of(list).collect(joining(",")));
            }
        }
        return excel;
    }

    private void writeJsonString(JsonGenerator writer, String str) {
        try {
            writer.writeString(str);
        } catch (IOException ex) {
            Logger.getLogger(NMRMSTranslatorServlet.class
                    .getName()).log(Level.SEVERE, null, ex);
        }
    }

    private MWStructArray cast(Object obj) {
        return (MWStructArray) obj;
    }

    private String writeCompoundNames(Object[] object) {
        return Arrays.stream(object)
                .map(name -> (char[][])name)
                .filter(chars -> chars.length != 0)
                .map(chars -> new String(chars[0]))
                .collect(joining("|"));
    }
}