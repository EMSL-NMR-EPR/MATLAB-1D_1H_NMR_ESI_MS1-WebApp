/*
    For information on license, see: ${PROJECT_DIRECTORY}/LICENSE
 */
package servlet;

import com.fasterxml.jackson.core.JsonFactory;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

@WebListener
public class ServletLifeCycleListener implements ServletContextListener {

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        sce.getServletContext().setAttribute("JSON_FACTORY", new JsonFactory());
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        sce.getServletContext().removeAttribute("JSON_FACTORY");
    }
    
}
