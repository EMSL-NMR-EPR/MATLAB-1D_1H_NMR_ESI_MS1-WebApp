package servlet;

import java.io.*;
import java.nio.file.*;
import static java.nio.file.FileVisitResult.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.*;
import java.util.logging.*;
import javax.servlet.annotation.WebListener;
import javax.servlet.http.*;

// TODO: Remove System.out.println();
@WebListener
public class UserSessionListener implements HttpSessionListener {

    @Override
    public void sessionCreated(HttpSessionEvent se) {
        System.out.println("CREATED NEW SESSION");
        Path userDir = Paths.get(se.getSession().getServletContext().getRealPath("/WEB-INF/temp"), "user_" + String.valueOf(se.getSession().getCreationTime() + new Random().nextInt(1000)));
        try {
            Files.createDirectories(userDir.resolve("csv"));
        } catch (IOException ex) {
            Logger.getLogger(UserSessionListener.class.getName()).log(Level.SEVERE, null, ex);
        }
        se.getSession().setAttribute("userDir", userDir);
    }

    @Override
    public void sessionDestroyed(HttpSessionEvent se) {
        try {
            System.out.println("DESTROYING THIS SESSION");
            Path userDir = (Path) se.getSession().getAttribute("userDir");
            System.out.println("userDir: " + userDir);
            Files.walkFileTree(userDir, new SimpleFileVisitor<Path>() {
                @Override
                public FileVisitResult postVisitDirectory(Path dir, IOException exc) throws IOException {
                    if (exc == null)
                        if (Files.list(dir).count() == 0)
                            Files.delete(dir);
                    return CONTINUE;
                }

                @Override
                public FileVisitResult visitFileFailed(Path file, IOException exc) throws IOException {
                    return CONTINUE;
                }

                @Override
                public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                    Files.delete(file);
                    return CONTINUE;
                }
                
            });
        } catch (IOException ex) {
            Logger.getLogger(UserSessionListener.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
