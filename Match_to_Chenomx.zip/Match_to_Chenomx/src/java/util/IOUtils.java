/*
    For information on license, see: ${PROJECT_DIRECTORY}/LICENSE
 */
package util;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.channels.Channels;
import java.nio.channels.*;
import java.nio.file.*;
import static java.nio.file.StandardOpenOption.*;
import java.util.logging.*;
import javax.servlet.http.Part;

public class IOUtils {

    public static void copy(final Part part, final Path dir) {
        try (ReadableByteChannel rChannel = Channels.newChannel(new BufferedInputStream(part.getInputStream()))) {
             WritableByteChannel wChannel = Files.newByteChannel(dir.resolve(part.getName() + "_" + part.getSubmittedFileName()), CREATE, WRITE);
            write(rChannel, wChannel);
        } catch (IOException ex) {
            Logger.getLogger(IOUtils.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static void write(ReadableByteChannel rChannel, WritableByteChannel wChannel) {
        try {
            ByteBuffer buffer = ByteBuffer.allocateDirect(1024);
            while (rChannel.read(buffer) != -1) {
                buffer.flip();
                wChannel.write(buffer);
                buffer.clear();
            }
        } catch (IOException ex) {
            Logger.getLogger(IOUtils.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}