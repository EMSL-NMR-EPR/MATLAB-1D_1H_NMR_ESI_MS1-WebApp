/*
 For information on license, see: ${PROJECT_DIRECTORY}/LICENSE
 */
/* global d3 */
(function ($) {

    var fileNames = d3.selectAll("#form1 .input-group > input[type=text]").nodes();
    d3.selectAll("#form1 input[type=file]").on("change", function (d, i) {
        fileNames[i].value = this.files[0].name;
        fileNames[i].style.fontStyle = "normal";
        fileNames[i].style.color = "black";
    });

    $("#home-btn").click(function () {
        window.history.pushState({}, "", "/metabolomics/");
        d3.select(".content")
                .transition()
                .on("end", function () {
                    d3.select(this).style("opacity", "0")
                            .style("top", "0px")
                            .style("transform", "scale(0)");
                })
                .ease(d3.easePolyIn)
                .duration(500)
                .style("top", "1000px");

    });
    $("#show-form").click(function () {
        d3.select(".form-container")
                .transition()
                .ease(d3.easeBackOut)
                .duration(800)
                .style("transform", "scale(1)");
    });
    $(".close-form-container-btn").click(function () {
        d3.select(".form-container")
                .transition()
                .ease(d3.easeBackIn)
                .on("end", function () {
                    d3.select(this)
                            .style("left", "30%")
                            .style("transform", "scale(0) rotate(0deg)");
                })
                .duration(800)
                .style("transform", "rotate(180deg)")
                .style("left", "-2000px");
    });
    $("#upload").click(function () {
        $(".close-form-container-btn").click();
        graph();
    });

    $("#show-listview, #show-listview-link").click(function (event) {
        event.stopImmediatePropagation();
        if ($(".listview tr").size() === 0) {
            var data = getCompoundNames();
            var table = d3.select(".listview").select("table");
            var tr = table.selectAll("tr")
                    .data(data.compounds)
                    .enter()
                    .append("tr");
            tr.append("td")
                    .classed("checkbox", true)
                    .on("click", function () {
                        $(this).toggleClass("checked").find("i").toggleClass("fa-square-o fa-check-square-o popup-fast");
                        var graphs = $("svg");
                        if (graphs.find("g").size() > 0) {
                            graphs.find("g").remove();
                            graphs.next().remove();
                        }
                        if (options.style("visibility") === "hidden")
                            $(".listview").scroll();
                        if ($(".checked").size() > 0)
                            $("ul #done").show();
                        else
                            $("ul #done").hide();
                    })
                    .attr("id", function (d, i) { return i + 1; })
                    .append("i")
                    .classed("fa fa-square-o fa-lg", true);
            tr.append("td")
                    .text(function (d) { return d; });
            $(".content").scroll(function () {
                $(".listview").offset({top: 0, left: "100%"});
            });
        }
        // d3.select(".content-wrapper").call(translate, "translateX(-25%)", 1000);
        d3.select(".listview").call(translate, "translateX(0%)", 1000);
    });
    var options = d3.select(".options-floated");
    $(".listview").scroll(function () {
        if ($(this).scrollTop() <= 90)
            toggleRotate(options, "rotate(-180deg)", true);
        else if (options.style("visibility") === "hidden")
            toggleRotate(options, "rotate(0deg)").style("visibility", "visible");
    });
    $(".bs-tooltip").tooltip();
    $(".email-container .send, .email").tooltip({title: "Send a message to this email address using a pre-installed mail client program", placement: "bottom"});
    $("#download-csv").click(function (event) {
        event.stopImmediatePropagation();
        $(this).toggleClass("active-nav-item").find("ul").slideToggle(250);
    }).find("*").each(function () {
        $(this).click(function (event) {
            event.stopImmediatePropagation();
            $(".excel-file-selection").slideUp().parent().removeClass("active-nav-item");
        });
    });
    $(".content-wrapper, .graph-container *").click(function () {
        $(".excel-file-selection").slideUp(250).parent().removeClass("active-nav-item");
        $(".dialog").fadeOut().addClass("drop").removeClass("rotate-in");
        d3.select(".listview").call(translate, "translateX(50%)", 1500);
        toggleRotate(options, "rotate(-180deg)", true);
    });

    $("ul #select-all").click(function () {
        $("ul #done").show();
        d3.selectAll(".checkbox")
                .classed("checked", "true")
                .each(function () { $(this).find("i").removeClass("fa-square-o").addClass("fa-check-square-o popup-fast"); });
    });

    $("ul #unselect-all").click(function () {
        $("ul #done").hide();
        d3.selectAll(".checkbox")
                .classed("checked", false)
                .each(function () {
                    $(this).find("i").addClass("fa-square-o").removeClass("popup-fast fa-check-square-o");
                });
    });
    $("ul #scroll-to-bottom").click(function() {
       $(".listview").animate({scrollTop: $(".listview").get(0).scrollHeight - $(document).height()}, 3000, "easeOutExpo");
    });
    $("ul #scroll-to-top").click(function() {
       $(".listview").animate({scrollTop: "0"}, 3000, "easeOutQuart");
    });

    $(".listview #done").click(function () {
        $(".content-wrapper").click();
        var indexes = Array.prototype.map.call(d3.selectAll(".listview .checked").nodes(), function (e) {
            return e.id;
        }).reduce(function (prev, next) {
            return prev + "     " + next;
        });
        $("#form1 #names").val(indexes).parent().find("#file1").val(null);
        if ($(".form-container").css("transform") === "matrix(0, 0, 0, 0, 0, 0)") {
            if ($("#form1 #file2").get(0).files.length !== 0)
                graph();
            else
                $("nav #show-form").click();
        } 
    });
    $(".options-floated #done").click(function () {
        $(".listview #done").click();
        toggleRotate(options, "rotate(-180deg)", true);
    });
    $("#usage-guide").click(function (event) {
        event.stopImmediatePropagation();
        var dialog = $(".dialog");
        dialog.width("30%")
                .find(".dialog-header-title")
                .text("Usage Guide");
        dialog.fadeIn()
                .css({bottom: $(this).position().top - 15, left: "calc(" + ($(this).offset().left - dialog.width() / 2) + "px + 2.5em)"})
                .addClass("rotate-in")
                .removeClass("drop")
                .find("#for-usage-guide")
                .show()
                .next()
                .hide();
    });
    $(".dialog-header-close-btn").click(function (event) {
        event.stopImmediatePropagation();
        $(".overlay").fadeOut();
        $(".dialog").fadeOut().removeClass("rotate-in").addClass("drop");
    });

    $("#contact-us").click(function (event) {
        event.stopImmediatePropagation();
        var dialog = $(".dialog");
        dialog.width("25%")
                .find(".dialog-header-title")
                .text("Mail to");
        dialog.fadeIn()
                .css({bottom: $(this).position().top - 15, left: "calc(" + ($(this).offset().left - dialog.width() / 2) + "px + 2.5em)"})
                .addClass("rotate-in")
                .removeClass("drop")
                .find("#for-usage-guide")
                .hide()
                .next()
                .show();
    });
    function getCompoundNames() {
        var data = localStorage.getItem("compounds");
        if (data)
            data = JSON.parse(data);
        else
            $.ajax("/metabolomics/NMRMSTranslator/compounds", {
                "method": "GET",
                "Accept": "application/json",
                "async": false,
                "success": function (d) {
                    data = d;
                    data.compounds = data.compounds.map(function (e) {
                        return e.trim();
                    });
                    localStorage.setItem("compounds", JSON.stringify(data));
                },
                "error": function (xhr) {
                    console.log(xhr);
                    return null;
                }
            });
        return data;
    }
    function translate(selection, t, d) {
        selection.transition()
                .duration(d)
                .ease(d3.easePolyOut)
                .style("transform", t);
    }
    function graph() {
        /*if (!pnnl.validation.validate("form1", ["file1", "file2", "file3"]))
         return;*/
        pnnl.draw.drawSpinner();
        pnnl.draw.drawOverlay();
        var file1 = document.getElementById("file1").files[0];
        var file2 = document.getElementById("file2").files[0];
        var file3 = document.getElementById("file3").files[0];
        var formData = new FormData();
        formData.append("file1", file1 ? file1 : $("#form1 #names").val());
        formData.append("username", $("#form1 #username").val());
        formData.append("institution", $("#form1 #institution").val());
        formData.append("file2", file2);
        if (file3)
            formData.append("file3", file3);
        var xhr = new XMLHttpRequest();
        xhr.open("POST", "/metabolomics/NMRMSTranslator/graphs");
        xhr.onreadystatechange = function () {
            pnnl.draw.removeSpinnerOverlay();
            if (xhr.readyState === 4) {
                var data = JSON.parse(xhr.response);
                showDownloadButton(data.url, data.creationTime);
                data = normalize(data);
                draw("#graph-1-container #graph-1", data.pos, ["mass_list_pos1", "mass_list_pos2", "list_pos1", "list_pos2", "pos_name_list"]);
                draw("#graph-2-container #graph-2", data.neg, ["mass_list_neg1", "mass_list_neg2", "list_neg1", "list_neg2", "neg_name_list"]);
            }
        };
        xhr.send(formData);
    }
    function draw(s, data, fields) {
        var selector = d3.select(s);
        selector.select("g").remove();
        $(s).next(".data-values").remove();
        var margin = {"top": 30, "right": 10, "bottom": 40, "left": 65};
        var width = $(s).width() - margin.left - margin.right;
        var height = $(s).height() - margin.top - margin.bottom;
        var svg = selector.append("g")
                .attr("width", width)
                .attr("height", height)
                .attr("transform", "translate(" + margin.left + "," + margin.top + ")");

        svg.append("rect")
                .attr("x", 0)
                .attr("y", 0)
                .attr("fill-opacity", "0")
                .attr("width", width)
                .attr("height", height);
        var labels = d3.select(selector.node().parentElement)
                .append("div")
                .attr("class", "data-values");
        $(labels.node()).draggable();
        var label = labels.selectAll("data-value")
                .data(fields)
                .enter()
                .append("div");
        label.append("span")
                .attr("class", "data-label")
                .text(function (d) { return d + ": "; });
        label.append("span")
                .attr("id", function (d) { return d; })
                .style("color", "blueviolet");

        var mass1 = labels.select("#" + fields[0]);
        var mass2 = labels.select("#" + fields[1]);
        var list1 = labels.select("#" + fields[2]);
        var list2 = labels.select("#" + fields[3]);
        var names = labels.select("#" + fields[4]).append("ul");

        var xScale1 = d3.scaleLinear()
                .domain(d3.extent(data.mass1))
                .range([0, width]);
        var xScaleBand1 = d3.scaleBand()
                .domain(data.mass1)
                .range([0, width]);
        var xAxis = d3.axisBottom(xScale1);
        var mass2Max = d3.max(data.mass2);
        data.list2.push(-mass2Max);
        var yScale1 = d3.scaleLinear()
                .domain([0, mass2Max])
                .range([height / 2, 0]);
        var yAxis1 = d3.axisLeft(yScale1);
        console.log(mass2Max);
        var xScaleBand2 = d3.scaleBand()
                .domain(data.list1)
                .range([0, width]);
        var yScale2 = d3.scaleLinear()
                .domain(d3.extent(data.list2))
                .range([height, height / 2]);
        var yAxis2 = d3.axisLeft(yScale2);
        var matchingRect;
        var x = svg.append("g")
                .attr("class", "x axis")
                .attr("transform", "translate(0," + height + ")")
                .call(xAxis);
        svg.append("text")
                .text("m/z (mass-to-charge ratio)")
                .attr("x", (width - 161) / 2)
                .attr("y", 550)
                .attr("dy", "1.75em")
                .attr("fill", "black")
                .style("font-size", "13px");

        svg.append("g")
                .attr("class", "y axis")
                .style("stroke", "#008000")
                .call(yAxis1)
                .append("text")
                .attr("x", 125)
                .attr("y", -10)
                .attr("fill", "black")
                .attr("stroke", "none")
                .style("font-size", "13px")
                .text("Intensity (ion Count)");
        svg.append("defs")
                .append("clipPath")
                .attr("id", "clip")
                .append("rect")
                .attr("width", width)
                .attr("height", height);
        var g = svg.append("g").attr("clip-path", "url(#clip)");
        g.append("g")
                .attr("id", "pos")
                .attr("class", "zoomable")
                .selectAll("rect")
                .data(data.mass2)
                .enter()
                .append("rect")
                .attr("class", "bar")
                .attr("x", function (d, i) { return i * xScaleBand1.bandwidth(); })
                .attr("y", function (d) { return yScale1(d); })
                .attr("width", xScaleBand1.bandwidth())
                .attr("height", function (d) { return height / 2 - yScale1(d); })
                .attr("fill", "#008000")
                .on("mouseover", function (d, i) {
                    d3.select(this).transition().attr("fill", "orange");
                    matchingRect = Array.prototype.slice.call(selector.select("#neg").node().children, 0)
                            .filter(function (val, index) {
                                return index === i;
                            })[0];
                    d3.select(matchingRect).transition().attr("fill", "red");
                    $(labels.node()).show();
                    mass1.text(data.mass1[i].toFixed(8));
                    mass2.text(d);
                    list1.text(data.list1[i].toFixed(8));
                    list2.text(data.list2[i]);
                    showCompoundName(names, data.name[i]);
                })
                .on("mouseout", function () {
                    d3.select(this).transition().attr("fill", "#008000");
                    d3.select(matchingRect).transition().attr("fill", "steelblue");
                });

        svg.append("g")
                .attr("class", "y axis")
                .style("stroke", "steelblue")
                .call(yAxis2);
        g.append("g")
                .attr("id", "neg")
                .attr("class", "zoomable")
                .selectAll("rect")
                .data(data.list2)
                .enter()
                .append("rect")
                .attr("class", "bar")
                .attr("x", function (d, i) {
                    return i * xScaleBand2.bandwidth();
                })
                .attr("y", height / 2)
                .attr("width", xScaleBand2.bandwidth())
                .attr("height", function (d) {
                    return yScale2(d) - height / 2;
                })
                .attr("fill", "steelblue")
                .on("mouseover", function (d, i) {
                    d3.select(this).transition().attr("fill", "red");
                    matchingRect = Array.prototype.slice.call(selector.select("#pos").node().children, 0)
                            .filter(function (val, index) {
                                return index === i;
                            })[0];
                    d3.select(matchingRect).transition().attr("fill", "orange");
                    $(labels.node()).show();
                    mass1.text(data.mass1[i].toFixed(8));
                    mass2.text(data.mass2[i]);
                    list1.text(data.list1[i].toFixed(8));
                    list2.text(d);
                    showCompoundName(names, data.name[i]);
                })
                .on("mouseout", function () {
                    d3.select(this).transition().attr("fill", "steelblue");
                    d3.select(matchingRect).transition().attr("fill", "#008000");
                });

        svg.append("g")
                .attr("transform", "translate(395,10)")
                .selectAll("text")
                .data(fields)
                .enter()
                .append("text")
                .attr("y", function (d, i) {
                    return i * 15;
                })
                .attr("id", function (d) {
                    return d;
                });
        var zoom = d3.zoom()
                .scaleExtent([1, 20])
                .translateExtent([margin.left, margin.top], [width, height])
                .on("zoom", function () {
                    selector.selectAll(".zoomable").attr("transform", "translate(" + d3.event.transform.x + ",0) scale(" + d3.event.transform.k + ",1)");
                    x.call(xAxis.scale(d3.event.transform.rescaleX(xScale1)));
                });
        selector.select("rect").call(zoom);

        $(selector.node()).prev(".header").find(".reset-graph").on("click", function () {
            selector.select("rect").transition().duration(1000).ease(d3.easePolyOut).call(zoom.transform, d3.zoomIdentity);
        });
        $(".graph #neg rect:last-child").remove();
    }
    function showCompoundName(ul, names) {
        names = names.filter(function(name) { return name.length !== 0; });
        var update = ul.selectAll("li")
                .data(names)
                .style("display", "list-item")
                .text(function(name) { return name; });
        update.enter()
                .append("li")
                .text(function(name) { return name; });
        update.exit()
                .style("display", "none");
    }
    function normalize(data) {
        return {
            pos: {
                mass1: data["mass_list_pos1"],
                mass2: data["mass_list_pos2"],
                list1: data["list_pos1"],
                list2: data["list_pos2"],
                name: data["pos_name_list"]
            },
            neg: {
                mass1: data["mass_list_neg1"],
                mass2: data["mass_list_neg2"],
                list1: data["list_neg1"],
                list2: data["list_neg2"],
                name: data["neg_name_list"]
            }
        };
    }

    function showDownloadButton(url, time) {
        var timeFormat = d3.timeFormat("%H:%M:%S");
        var clone = $("#download-csv").css("display", "inline-block")
                .find("#template")
                .clone()
                .attr("id", null);
        clone.find("a")
                .attr("href", "/metabolomics/NMRMSTranslator/download?url=" + url)
                .find(".excel-file-name")
                .text(url)
                .next()
                .text("Created at: " + timeFormat(new Date(time)));
        clone.insertAfter("#download-csv ul #template");
    }
    function toggleRotate(options, transform, hide) {
        var transition = options.transition()
                .duration(500)
                .ease(d3.easePolyOut);
        if (hide)
            transition.on("end", function () { options.style("visibility", "hidden"); });
        transition.style("transform", transform);
        return transition;
    }
})(jQuery);